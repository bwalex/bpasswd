self.on("click", function(node, data) {
  self.postMessage(node.src);
});