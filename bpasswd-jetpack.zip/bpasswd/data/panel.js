var pwdInput = document.getElementById('bpasswd-password');
var saltInput = document.getElementById('bpasswd-salt');
var dkeyInput = document.getElementById('bpasswd-dkey');
var dkeyBtn = document.getElementById('bpasswd-derive-key');
var revealChk = document.getElementById('bpasswd-show-pwd');

dkeyBtn.onclick = function() {
  var cost = 6;
  var dkey = pwdInput.value + "!!" + saltInput.value;
  dkeyInput.value = dkey;
  dkeyInput.focus();
  dkeyInput.select();
  self.port.emit("copy", dkey);
};

revealChk.onchange = function() {
  pwdInput.type = revealChk.checked ? "text" : "password";
};

self.port.on("hide", function() {
  pwdInput.value = "";
  saltInput.value = "";
  dkeyInput.value = "";
});

self.port.on("show", function(opts) {
  self.port.emit('resize', {
    "width" : document.body.clientWidth,
    "height": document.body.clientHeight
  });

  saltInput.value = opts.currentUrl;
  pwdInput.focus();
});

